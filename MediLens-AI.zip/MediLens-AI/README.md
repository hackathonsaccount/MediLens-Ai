# MediLens AI

MediLens AI is an educational report-reading workspace. It helps people inspect extracted report text, learn common terms, follow general-information sources, and prepare editable questions for a clinician. It does not diagnose, interpret personal results, or recommend treatment.

## Features

- Upload a PDF, JPG, or PNG for transient text extraction. Files are limited to 10 MiB and PDF processing is limited to 20 pages.
- Review extracted sections, page locations, values, units, and printed reference ranges.
- Browse an English/Arabic glossary and verified educational references.
- Prepare, edit, copy, print, and download discussion notes.
- Explore a clearly labeled fictional report and optional sample-only explanations.
- Use a warm liquid-glass interface with scroll reveals, a reading-progress indicator, larger type, high contrast, reduced-motion support, and Arabic right-to-left layout.

## Privacy and scope

Uploaded files are processed in memory for extraction and are not retained. Report content is not sent to an AI provider. The optional OpenAI integration is limited to curated terms from the fictional sample; without `OPENAI_API_KEY`, the app uses a static sample explanation. Do not treat the fictional sample or section labels as clinical guidance.

## Machine-learning section organizer

The API uses a trained scikit-learn TF-IDF/logistic-regression model to sort extracted report lines into five document-layout categories. It is not trained to evaluate health results.

Training data and evaluation data are synthetic and kept separate:

- `ml/dataset/train.csv`: 60 training examples
- `ml/dataset/test.csv`: 20 held-out test examples
- `ml/train.py`: trains the model, prints class metrics, and writes the model consumed by the API
- `artifacts/api-server/src/routes/section-classifier.ts`: performs inference with the generated model

Retrain with:

```sh
python3 ml/train.py
```

The current macro-F1 is 1.00 on this small synthetic test split (four test rows per label). This result is not evidence of real-world or clinical accuracy. A larger, independently labeled, representative dataset and appropriate clinical review would be needed before making stronger claims.

## Run the workspace

From the repository root:

```sh
pnpm --filter @workspace/medilens-ai run dev
pnpm --filter @workspace/api-server run dev
```

The Replit workspace already has managed web and API workflows for these commands.

## Checks

```sh
pnpm --filter @workspace/medilens-ai run typecheck
pnpm --filter @workspace/api-server run typecheck
pnpm --filter @workspace/mockup-sandbox run typecheck
pnpm --filter @workspace/api-server run build
PORT=5000 BASE_PATH=/ pnpm --filter @workspace/medilens-ai run build
```

The application is a React/Vite frontend backed by the workspace's Express API and shared generated API types. Uploaded documents and session notes are not persisted to a database.
